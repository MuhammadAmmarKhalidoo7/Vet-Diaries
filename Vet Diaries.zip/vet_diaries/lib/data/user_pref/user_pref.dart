import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserPref {
  static saveUser(
      // Map<String, String> user,
      bool isAdmin,
      bool rememberMe) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    // pref.setString('userName', user['userName']!);
    // pref.setString('email', user['email']!);
    pref.setBool('isAdmin', isAdmin);
    pref.setBool('rememberMe', rememberMe);
    // pref.setString('token', user['token']!);

    // print(user);
  }

  void checkUserStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? isAdmin = prefs.getBool('isAdmin');
    bool? rememberMe = prefs.getBool('rememberMe');

    if (rememberMe == true && isAdmin == true) {
      // Navigate to the admin screen
    } else {
      // Navigate to the normal user screen or login screen
    }
  }
  // static Future<Map<String, String?>> getUser() async {
  //   Map<String, String?> user;
  //   SharedPreferences pref = await SharedPreferences.getInstance();
  //   user = {
  //     'userName': pref.getString('userName'),
  //     'fullName': pref.getString('fullName'),
  //     'profilePicture': pref.getString('profilePicture'),
  //     'phoneNumber': pref.getString('phoneNumber'),
  //     'email': pref.getString('email'),
  //     'token': pref.getString('token'),
  //     'type': pref.getString('type'),
  //   };
  //   return user;
  // }

  static clearUser() async {
    FirebaseAuth.instance.signOut();
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.clear();
  }
}
