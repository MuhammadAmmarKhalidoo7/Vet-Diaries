// import 'package:intl/intl.dart';
// import 'package:vet_diaries/ui/record_save_screen/record_save_screen.dart';
// import 'package:vet_diaries/ui/view_barrel.dart';

// class BirdDetailScreen extends StatefulWidget {
//   const BirdDetailScreen({super.key});

//   @override
//   State<BirdDetailScreen> createState() => _BirdDetailScreenState();
// }

// class _BirdDetailScreenState extends State<BirdDetailScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Birds'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               children: [
//                 const Text(
//                   "Enter Bird Details:",
//                   style: TextStyle(
//                     color: Colors.black,
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold,
//                     letterSpacing: 1,
//                     wordSpacing: 2,
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 DropdownButtonFormField<String>(
//                   value: selectBirdType,
//                   items: birdTypes.map((String type) {
//                     return DropdownMenuItem<String>(
//                       value: type,
//                       child: Text(type),
//                     );
//                   }).toList(),
//                   onChanged: (String? newValue) {
//                     setState(() {
//                       selectBirdType = newValue!;
//                     });
//                   },
//                   decoration: const InputDecoration(
//                     labelText: 'Bird Type',
//                     hintText: 'Select an bird type',
//                   ),
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return 'Please select an bird type';
//                     }
//                     return null;
//                   },
//                 ),
//                 // TextFormField(
//                 //   controller: _birdTypeController,
//                 //   decoration: const InputDecoration(
//                 //     labelText: 'Bird type',
//                 //     hintText: 'Enter bird type here',
//                 //   ),
//                 //   validator: (value) {
//                 //     if (value!.isEmpty) {
//                 //       return 'Bird type is required';
//                 //     }
//                 //     return null; // Return null if the input is valid
//                 //   },
//                 // ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   controller: _birdAgeController,
//                   keyboardType: TextInputType.number,
//                   obscureText: false,
//                   decoration: const InputDecoration(
//                     labelText: 'Age',
//                     hintText: 'Enter bird age here',
//                   ),
//                   validator: (value) {
//                     if (value!.isEmpty) {
//                       return 'Age is required';
//                     }
//                     return null; // Return null if the input is valid
//                   },
//                 ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   controller: _diagnosedDiseaseController,
//                   obscureText: false,
//                   decoration: const InputDecoration(
//                     labelText: 'Enter diagnosed disease',
//                     hintText: 'Enter diagnosed disease here',
//                   ),
//                   validator: (value) {
//                     if (value!.isEmpty) {
//                       return 'Diagnosed disease is required';
//                     }
//                     return null; // Return null if the input is valid
//                   },
//                 ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   onTap: () {
//                     _selectDate(context);
//                   },
//                   controller: _nextVisitController,
//                   obscureText: false,
//                   decoration: const InputDecoration(
//                     labelText: 'Next visit',
//                     hintText: '',
//                   ),
//                 ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   controller: _medicineGivenController,
//                   obscureText: false,
//                   decoration: const InputDecoration(
//                     labelText: 'Medicine given',
//                     hintText: 'Enter given medicine here',
//                   ),
//                 ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   controller: _medicineChargesController,
//                   obscureText: false,
//                   keyboardType: TextInputType.number,
//                   decoration: const InputDecoration(
//                     labelText: 'Medicine charges',
//                     hintText: 'RS:',
//                   ),
//                 ),
//                 const SizedBox(height: 20.0),
//                 ElevatedButton(
//                   onPressed: () {
//                     if (_formKey.currentState!.validate()) {
//                       Get.to(const RecordSavedDoneDoctor());

//                       // Navigator.pushNamed(context, '/done');
//                     }
//                   },
//                   child: const Text('Save'),
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
