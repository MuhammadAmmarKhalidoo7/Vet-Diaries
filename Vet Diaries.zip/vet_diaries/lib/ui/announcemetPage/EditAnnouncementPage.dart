// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';

// class EditAnnouncementPage extends StatefulWidget {
//   final QueryDocumentSnapshot<Map<String, dynamic>> announcement;

//   const EditAnnouncementPage({Key? key, required this.announcement})
//       : super(key: key);

//   @override
//   _EditAnnouncementPageState createState() => _EditAnnouncementPageState();
// }

// class _EditAnnouncementPageState extends State<EditAnnouncementPage> {
//   final TextEditingController _descriptionController = TextEditingController();

//   @override
//   void initState() {
//     super.initState();
//     _descriptionController.text = widget.announcement['description'];
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Edit Announcement'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             Image.network(
//               widget.announcement['image_url'],
//               height: 150,
//               fit: BoxFit.cover,
//             ),
//             const SizedBox(height: 16),
//             TextField(
//               controller: _descriptionController,
//               decoration: const InputDecoration(
//                 labelText: 'Description',
//               ),
//             ),
//             const SizedBox(height: 16),
//             ElevatedButton(
//               onPressed: () {
//                 _updateAnnouncement();
//               },
//               child: const Text('Update Announcement'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   void _updateAnnouncement() async {
//     try {
//       // Update logic to Firebase Firestore
//       await FirebaseFirestore.instance
//           .collection('announcements')
//           .doc(widget.announcement.id)
//           .update({
//         'description': _descriptionController.text,
//         // Add other fields you want to update
//       });

//       // Navigate back to the announcements list page
//       Navigator.pop(context);
//     } catch (e) {
//       print('Error updating announcement: $e');
//       // Handle the error, you may want to show a dialog or snackbar
//     }
//   }
// }
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class EditAnnouncementPage extends StatefulWidget {
  final QueryDocumentSnapshot<Map<String, dynamic>> announcement;

  const EditAnnouncementPage({Key? key, required this.announcement})
      : super(key: key);

  @override
  _EditAnnouncementPageState createState() => _EditAnnouncementPageState();
}

class _EditAnnouncementPageState extends State<EditAnnouncementPage> {
  bool _uploadInProgress = false;

  final TextEditingController _descriptionController = TextEditingController();
  File? _newImage;
  final ImagePicker _imagePicker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _descriptionController.text = widget.announcement['description'];
  }

  @override
  Widget build(BuildContext context) {
    if (_uploadInProgress) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Edit Announcement'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Display the current or new image
              _newImage != null
                  ? Image.file(
                      _newImage!,
                      height: 150,
                      fit: BoxFit.cover,
                    )
                  : Image.network(
                      widget.announcement['image_url'],
                      height: 150,
                      fit: BoxFit.cover,
                    ),
              const SizedBox(height: 16),
              // Button to choose a new image
              ElevatedButton(
                onPressed: () {
                  _getImage();
                },
                child: const Text('Select New Image'),
              ),
              const SizedBox(height: 16),
              // Text field to edit the description
              TextField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                ),
              ),
              const SizedBox(height: 16),
              // Button to update the announcement
              ElevatedButton(
                onPressed: () {
                  _updateAnnouncement();
                },
                child: const Text('Update Announcement'),
              ),
            ],
          ),
        ),
      );
    }
  }

  // Method to update the announcement in Firestore
  void _updateAnnouncement() async {
    try {
      setState(() {
        _uploadInProgress = true;
      });
      // Check if there's a new image to upload
      String imageUrl = widget.announcement['image_url'];
      if (_newImage != null) {
        // Upload the new image and get the new URL
        imageUrl = await _uploadImageToStorage();
      }

      // Update the 'description' and 'image_url' fields in the Firestore document
      await FirebaseFirestore.instance
          .collection('announcements')
          .doc(widget.announcement.id)
          .update({
        'description': _descriptionController.text,
        'image_url': imageUrl,
        // You can add other fields here if needed
      });
      setState(() {
        _uploadInProgress = false;
      });
      // Navigate back to the announcements list page
      Navigator.pop(context);
    } catch (e) {
      setState(() {
        _uploadInProgress = false;
      });
      // Handle any errors that occur during the update
      print('Error updating announcement: $e');
      // You might want to show a dialog or snackbar to inform the user about the error
    }
  }

  // Method to get a new image from the gallery
  Future<void> _getImage() async {
    final pickedFile =
        await _imagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _newImage = File(pickedFile.path);
      }
    });
  }

  // Method to upload a new image to Firebase Storage

  Future<String> _uploadImageToStorage() async {
    try {
      setState(() {
        _uploadInProgress = true;
      });
      // Get a reference to the Firebase Storage
      firebase_storage.Reference storageRef =
          firebase_storage.FirebaseStorage.instance.ref();

      // Generate a unique filename for the image
      String filename = DateTime.now().millisecondsSinceEpoch.toString();

      // Upload the image to a 'announcements' folder with the generated filename
      firebase_storage.UploadTask uploadTask =
          storageRef.child('announcements/$filename.jpg').putFile(_newImage!);

      // Wait for the upload to complete
      await uploadTask;

      // Get the URL of the uploaded image
      String imageUrl = await storageRef
          .child('announcements/$filename.jpg')
          .getDownloadURL();
      setState(() {
        _uploadInProgress = false;
      });
      // Return the URL
      return imageUrl;
    } catch (e) {
      setState(() {
        _uploadInProgress = false;
      });
      print('Error uploading image: $e');
      // Handle the error, you may want to show a dialog or snackbar
      rethrow; // Rethrow the error to notify the calling function
    }
  }
}
