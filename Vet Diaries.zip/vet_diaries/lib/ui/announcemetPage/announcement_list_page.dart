import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'EditAnnouncementPage.dart'; // Import the EditAnnouncementPage

class AnnouncementsListPage extends StatelessWidget {
  const AnnouncementsListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Announcements List'),
      ),
      body: const Padding(
        padding: EdgeInsets.all(8.0),
        child: AnnouncementsList(),
      ),
    );
  }
}

class AnnouncementsList extends StatelessWidget {
  const AnnouncementsList({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream:
          FirebaseFirestore.instance.collection('announcements').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const CircularProgressIndicator();
        }

        var announcements = snapshot.data!.docs;

        if (announcements.isEmpty) {
          return const Center(child: Text('No announcements available'));
        }

        return ListView.builder(
          itemCount: announcements.length,
          itemBuilder: (context, index) {
            var announcement = announcements[index];
            var description = announcement['description'];
            var imageUrl = announcement['image_url'];

            return Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () {
                      // Call a function to delete the announcement
                      _deleteAnnouncement(announcement.id);
                    },
                  ),
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(imageUrl),
                  ),
                  title: Text(description),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            EditAnnouncementPage(announcement: announcement),
                      ),
                    );
                  },
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _deleteAnnouncement(String announcementId) async {
    try {
      await FirebaseFirestore.instance
          .collection('announcements')
          .doc(announcementId)
          .delete();
    } catch (e) {
      print('Error deleting announcement: $e');
      // Handle error, e.g., show a snackbar or display an error message
    }
  }
}
