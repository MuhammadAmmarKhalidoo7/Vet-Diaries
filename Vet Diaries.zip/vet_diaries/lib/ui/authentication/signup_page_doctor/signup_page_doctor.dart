import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:vet_diaries/ui/authentication/signup_success_doctor/signup_success_doctor.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class DoctorSignUpPage extends StatefulWidget {
  const DoctorSignUpPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<DoctorSignUpPage> {
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  String _password = '';
  String _confirmPassword = '';
  String _email = '';
  String _name = '';
  String _phoneNumber = '';

  bool _passwordVisible = false;
  bool _confirmPasswordVisible = false;
  bool _isLoading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sign Up'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Image.asset(
                'images/doctorlogin.jpg', // Replace with your logo image path
                height: 250.0,
                width: double.infinity,
                fit: BoxFit.contain,
              ),
              const SizedBox(
                height: 20,
              ),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Name is required';
                  }
                  return null;
                },
                // onSaved: (value) {
                //   _name = value!;
                // },
              ),
              const SizedBox(height: 6),
              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your email address.';
                  }
                  if (!EmailValidator.isValid(value)) {
                    return 'Invalid email address.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 6),
              TextFormField(
                controller: _phoneNumberController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Phone number is required';
                  }
                  return null;
                },
                // onSaved: (value) {
                //   _name = value!;
                // },
              ),
              const SizedBox(height: 6),
              TextFormField(
                obscureText: !_passwordVisible,
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Password',
                  suffixIcon: IconButton(
                    icon: Icon(
                      _passwordVisible
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _passwordVisible = !_passwordVisible;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 6),
              TextFormField(
                obscureText: !_confirmPasswordVisible,
                controller: _confirmPasswordController,
                decoration: InputDecoration(
                  labelText: 'Confirm Password',
                  suffixIcon: IconButton(
                    icon: Icon(
                      _confirmPasswordVisible
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _confirmPasswordVisible = !_confirmPasswordVisible;
                        // Navigator.push(
                        //   context,
                        //   MaterialPageRoute(builder: (context) => sucessfull()),
                        // );
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 32),
              RoundedButton(
                buttonColor: Colors.blue,
                textColor: Colors.white,
                buttonText: 'Sign Up',
                onPressed: _isLoading ? null : signUp,
              ),
              if (_isLoading)
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Center(child: CircularProgressIndicator()),
                ),
            ],
          ),
        ),
      ),
    );
  }

  signUp() async {
    {
      // Set loading to true to show the indicator
      setState(() {
        _isLoading = true;
      });
      // Trim input strings
      _name = _nameController.text.trim();
      _email = _emailController.text.trim();
      _phoneNumber = _phoneNumberController.text.trim();
      _password = _passwordController.text.trim();
      _confirmPassword = _confirmPasswordController.text.trim();

      // Validate passwords and perform signup logic
      if (_password.length < 6) {
        // Password is too short
        _showErrorDialog('Password must be at least 6 characters long.');
      } else if (_password == _confirmPassword) {
        // Passwords match, proceed with signup logic
        if (EmailValidator.isValid(_email)) {
          // Email is valid, proceed with signup
          // ignore: avoid_print
          print('Email: $_email, Password: $_password');
          try {
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
                email: _email, password: _password);
            SharedPreferences prefs = await SharedPreferences.getInstance();
            prefs.setBool('isAdmin', false);
            FirebaseAuth auth = FirebaseAuth.instance;
            User? user = auth.currentUser;

            if (user != null) {
              String uid = user.uid;

              await FirebaseFirestore.instance
                  .collection(doctorsCollection)
                  .doc(uid)
                  .set({
                'uid': uid,
                'name': _name,
                'email': _email,
                'phoneNumber': _phoneNumber,
                'isAdmin': !isAdmin
              });
              Get.off(const SignUpSuccessfullPage());
            }
          } on FirebaseAuthException catch (e) {
            _showErrorDialog(e.message ?? 'Error');
          } finally {
            // Set loading back to false
            setState(() {
              _isLoading = false;
            });
          }
          // Navigate to the successfull page
        } else {
          // Invalid email address
          _showErrorDialog('Invalid email address.');
        }
      } else {
        // Passwords do not match, show error message
        _showErrorDialog('Passwords do not match.');
      }
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
