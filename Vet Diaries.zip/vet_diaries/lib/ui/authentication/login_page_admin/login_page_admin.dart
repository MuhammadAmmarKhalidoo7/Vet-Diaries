import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:vet_diaries/data/user_pref/user_pref.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _AdminLoginPageState createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _rememberMe = false;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isPasswordVisible = false;

  // ignore: prefer_typing_uninitialized_variables
  // var _handleForgotPassword; // Track password visibility

  @override
  void initState() {
    super.initState();
    _loadRememberMePreference();
  }

  void _loadRememberMePreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _rememberMe = prefs.getBool('rememberMe') ?? false;
    });
  }

  void _saveRememberMePreference(bool value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rememberMe', value);
  }

  void _toggleRememberMe(bool value) {
    setState(() {
      _rememberMe = value;
      _saveRememberMePreference(value);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Login'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(30.0),
        children: [
          Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'images/admin.jpg', // Replace with your logo image path
                  height: 250.0,
                  width: double.infinity,
                  fit: BoxFit.contain,
                ),
                TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Email is required';
                    }
                    return null;
                  },
                  // onSaved: (value) {
                  //   _username = value!;
                  // },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    suffixIcon: IconButton(
                      icon: Icon(
                        _isPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() {
                          _isPasswordVisible = !_isPasswordVisible;
                        });
                      },
                    ),
                  ),
                  obscureText: !_isPasswordVisible, // Hide or show password
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Password is required';
                    }
                    return null;
                  },
                  // onSaved: (value) {
                  //   _password = value!;
                  // },
                ),
                const SizedBox(height: 20.0),
                // TextButton(
                //   onPressed: _handleForgotPassword,
                //   child: const Text(
                //     'Forgot Password?',
                //     style: TextStyle(
                //       color: Colors.blue,
                //     ),
                //   ),
                // ),
                Row(
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      onChanged: (value) => _toggleRememberMe(value!),
                    ),
                    const Text('Remember Me'),
                  ],
                ),
                const SizedBox(height: 20.0),
                RoundedButton(
                  buttonColor: Colors.blue,
                  buttonText: 'Admin Login',
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      // Perform login logic here using _username and _password

                      FirebaseAuth auth = FirebaseAuth.instance;
                      try {
                        UserCredential userCredential =
                            await auth.signInWithEmailAndPassword(
                          email: _emailController.text.trim().toString(),
                          password: _passwordController.text.trim().toString(),
                        );

                        User? user = userCredential.user;
                        bool isAdminHere = await checkIfUserIsAdmin(user);
                        if (isAdminHere) {
                          bool isAdmin = true;
                          UserPref.saveUser(isAdmin, _rememberMe);
                          Get.offNamed('/adminHomeScreen');
                        } else {
                          // If user is not admin, show a dialog or perform other actions
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text('Permission Denied'),
                                content: const Text(
                                    'You do not have permission to access the admin site.'),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: const Text('OK'),
                                  ),
                                ],
                              );
                            },
                          );
                        }
                      } on FirebaseAuthException catch (e) {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: const Text('Error'),
                              content: Text(e.toString()),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: const Text('OK'),
                                ),
                              ],
                            );
                          },
                        );
                      }
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> checkIfUserIsAdmin(User? user) async {
    CollectionReference doctorCollection =
        FirebaseFirestore.instance.collection(doctorsCollection);

    try {
      QuerySnapshot querySnapshot =
          await doctorCollection.where('email', isEqualTo: user?.email).get();

      if (querySnapshot.docs.isNotEmpty) {
        // Assuming 'isAdmin' is a boolean field in your collection
        return querySnapshot.docs.first['isAdmin'] ?? false;
      } else {
        return false; // User not found in the 'doctors' collection
      }
    } catch (error) {
      print('Error checking admin status: $error');
      return false; // Error occurred, consider treating as non-admin
    }
  }

//   Future<bool> checkIfUserIsAdmin(User? user) {

//   CollectionReference doctorsCollection =
//       FirebaseFirestore.instance.collection('doctors');

//   return doctorsCollection
//       .where('email', isEqualTo: user?.email)
//       .get()
//       .then((querySnapshot) {
//     if (querySnapshot.docs.isNotEmpty) {
//       // Assuming 'isAdmin' is a boolean field in your collection
//       return querySnapshot.docs.first['isAdmin'] ?? false;
//     } else {
//       return false; // User not found in the 'doctors' collection
//     }
//   }).catchError((error) {
//     print('Error checking admin status: $error');
//     return false; // Error occurred, consider treating as non-admin
//   });
// }
}
