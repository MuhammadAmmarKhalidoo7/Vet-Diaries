import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:vet_diaries/data/user_pref/user_pref.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class DoctorLoginPage extends StatefulWidget {
  const DoctorLoginPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _LoginPageState1 createState() => _LoginPageState1();
}

class _LoginPageState1 extends State<DoctorLoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool _rememberMe = false;
  String _email = '';
  String _password = '';
  bool _isPasswordVisible = false;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;
  @override
  void initState() {
    super.initState();
    _loadRememberMePreference();
  }

  void _loadRememberMePreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _rememberMe = prefs.getBool('rememberMe') ?? false;
    });
  }

  void _saveRememberMePreference(bool value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rememberMe', value);
  }

  void _toggleRememberMe(bool value) {
    setState(() {
      _rememberMe = value;
      _saveRememberMePreference(value);
    });
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Doctor Login'),
      ),
      body: Stack(
        children: [
          ListView(
            children: [
              Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'images/doctorlogin.jpg', // Replace with your logo image path
                      height: 250.0,
                      width: double.infinity,
                      fit: BoxFit.contain,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            controller: _emailController,
                            decoration: const InputDecoration(
                              labelText: 'Email',
                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Email is required';
                              }
                              return null;
                            },
                            onSaved: (value) {
                              _email = value!;
                            },
                          ),
                          const SizedBox(height: 20.0),
                          TextFormField(
                            controller: _passwordController,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _isPasswordVisible
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _isPasswordVisible = !_isPasswordVisible;
                                  });
                                },
                              ),
                            ),
                            obscureText:
                                !_isPasswordVisible, // Hide or show password
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Password is required';
                              }
                              return null;
                            },

                            onSaved: (value) {
                              _password = value!;
                            },
                          ),
                          const SizedBox(height: 20.0),
                          Row(
                            children: [
                              Checkbox(
                                value: _rememberMe,
                                onChanged: (value) {
                                  _toggleRememberMe(value!);
                                  print(_rememberMe);
                                },
                              ),
                              const Text('Remember Me'),
                            ],
                          ),
                          RoundedButton(
                            buttonColor: Colors.blue,
                            buttonText: 'Doctor Login',
                            onPressed: () async {
                              if (_formKey.currentState!.validate()) {
                                _formKey.currentState!.save();

                                setState(() {
                                  _isLoading = true;
                                });
                                try {
                                  UserCredential userCredential =
                                      await _auth.signInWithEmailAndPassword(
                                          email: _emailController.text
                                              .trim()
                                              .toString(),
                                          password: _passwordController.text
                                              .trim()
                                              .toString());
                                  User? user = userCredential.user;
                                  bool isDoctorHere =
                                      await checkIfUserIsAdmin(user);

                                  if (!isDoctorHere) {
                                    SharedPreferences prefs =
                                        await SharedPreferences.getInstance();
                                    prefs.setBool('isAdmin', false);
                                    bool isAdmin = false;
                                    UserPref.saveUser(isAdmin, _rememberMe);
                                    Get.offNamed('/doctorHomeScreen');
                                    print('Doctor login success!');
                                  } else {
                                    _showErrorDialog(
                                        'You do not have permission to access the User site.');
                                  }
                                } on FirebaseAuthException catch (e) {
                                  _showErrorDialog(e.message ?? 'Error');
                                  print('Error during doctor login: $e');
                                  setState(() {
                                    _isLoading = false;
                                  });
                                } finally {
                                  setState(() {
                                    _isLoading = false;
                                  });
                                  print("error");
                                }

                                // Navigator.pushNamed(context, '/patientrecord1');
                              }

                              // Add your button click logic here
                              print('doctorSignup clicked!');
                            },
                          ),
                          RoundedButton(
                            buttonColor: Colors.redAccent,
                            textColor: Colors.white,
                            buttonText: 'No Account Yet? Register Now',
                            onPressed: () {
                              Get.toNamed('/doctorSignup');

                              // Add your button click logic here
                              print('no Account clicked!');
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<bool> checkIfUserIsAdmin(User? user) async {
    CollectionReference doctorCollection =
        FirebaseFirestore.instance.collection(doctorsCollection);

    try {
      QuerySnapshot querySnapshot =
          await doctorCollection.where('email', isEqualTo: user?.email).get();

      if (querySnapshot.docs.isNotEmpty) {
        // Assuming 'isAdmin' is a boolean field in your collection
        return querySnapshot.docs.first['isAdmin'] ?? true;
      } else {
        return true; // User not found in the 'doctors' collection
      }
    } catch (error) {
      print('Error checking admin status: $error');
      return true; // Error occurred, consider treating as non-admin
    }
  }
}
