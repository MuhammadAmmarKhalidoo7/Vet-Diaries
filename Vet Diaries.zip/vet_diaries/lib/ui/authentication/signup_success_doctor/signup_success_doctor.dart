import 'package:vet_diaries/ui/view_barrel.dart';

class SignUpSuccessfullPage extends StatelessWidget {
  const SignUpSuccessfullPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Signup Successful'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 100,
            ),
            const SizedBox(height: 20),
            const Text(
              'Signup Successful!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Get.off(const DoctorHomePage());
                //  _submitForm,
              },
              child: const Text('continue'),
            ),
          ],
        ),
      ),
    );
  }
}
