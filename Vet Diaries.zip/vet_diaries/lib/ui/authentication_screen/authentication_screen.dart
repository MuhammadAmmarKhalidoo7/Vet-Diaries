import 'package:vet_diaries/ui/view_barrel.dart';

class AuthenticationScreen extends StatelessWidget {
  const AuthenticationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset(
                'images/doctor.jpg', // Replace with your logo image path
                height: 200.0,
                width: double.infinity,
                fit: BoxFit.fill,
              ),
              const SizedBox(height: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Vet Diaries",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                      wordSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 15),
                  const Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: 32.0), // Adjust the EdgeInsets as needed
                    child: Text(
                      "All types of health services for animals under one shelter",
                      style: TextStyle(color: Colors.black, fontSize: 20),
                    ),
                  ),
                  const Padding(padding: EdgeInsets.all(8.0)),
                  RoundedButton(
                    buttonText: 'Admin login',
                    onPressed: () {
                      Get.toNamed('/adminLogin');

                      // Add your button click logic here
                      print('adminLogin clicked!');
                    },
                  ),
                  RoundedButton(
                    buttonText: 'Doctor login',
                    onPressed: () {
                      Get.toNamed('/doctorLogin');

                      // Add your button click logic here
                      print('doctorLogin clicked!');
                    },
                  ),
                  RoundedButton(
                    buttonText: 'Doctor SignUp',
                    onPressed: () {
                      Get.toNamed('/doctorSignup');

                      // Add your button click logic here
                      print('doctorSignup clicked!');
                    },
                  ),
                  RoundedButton(
                    buttonColor: Colors.lightBlueAccent,
                    textColor: Colors.white,
                    buttonText: 'Help and Annoucements',
                    onPressed: () {
                      Get.toNamed('/helpLinePage');

                      // Add your button click logic here
                      print('Annoucements clicked!');
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
