import 'package:vet_diaries/ui/view_barrel.dart';

class RecordTypePatient extends StatelessWidget {
  const RecordTypePatient({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select type'),
      ),
      body: SingleChildScrollView(
        child: ListView(
          shrinkWrap: true,
          children: [
            Image.asset(
              'images/animal.jpg', // Replace with your logo image path
              height: 150.0,
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Get.to(OwnerInfo(
                  type: animal,
                ));
                // Navigator.pushNamed(context, '/animal record1');
              },
              child: const Text('Animal'),
            ),
            const SizedBox(height: 30),
            Image.asset(
              'images/bird.jpg', // Replace with your logo image path
              height: 190.0,
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Get.to(OwnerInfo(
                  type: bird,
                ));
              },
              child: const Text('Bird'),
            ),
          ],
        ),
      ),
    );
  }
}
