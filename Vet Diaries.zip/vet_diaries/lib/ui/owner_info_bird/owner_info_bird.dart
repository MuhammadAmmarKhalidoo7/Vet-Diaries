// import 'package:vet_diaries/ui/view_barrel.dart';

// class OwnerInfoBird extends StatelessWidget {
 

//   // ignore: unused_field

 
 
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Birds'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               children: [
//                 const Text(
//                   "Enter owner info:",
//                   style: TextStyle(
//                     color: Colors.black,
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold,
//                     letterSpacing: 1,
//                     wordSpacing: 2,
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 TextFormField(
//                   controller: _nameController,
//                   decoration: const InputDecoration(
//                     labelText: 'Name',
//                     hintText: 'Enter name here',
//                   ),
//                   validator: (value) {
//                     if (value!.isEmpty) {
//                       return 'Name is required';
//                     }
//                     return null; // Return null if the input is valid
//                   },
//                 ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   decoration: const InputDecoration(
//                     // border: OutlineInputBorder(),
//                     labelText: 'Enter CNIC',
//                   ),
//                   validator: (value) {
//                     if (value!.isEmpty) {
//                       return 'Please enter CNIC';
//                     } else if (!_cnicRegex.hasMatch(value)) {
//                       return 'Invalid CNIC format. Please enter a valid CNIC';
//                     }
//                     return null;
//                   },
//                 ),
//                 const SizedBox(height: 20.0),
//                 TextFormField(
//                   controller: _addressController,
//                   obscureText: true,
//                   decoration: const InputDecoration(
//                     labelText: 'Address',
//                     hintText: 'Enter address here',
//                   ),
//                   validator: (value) {
//                     if (value!.isEmpty) {
//                       return 'Address is required';
//                     }
//                     // You can add more address validation logic here if needed
//                     return null; // Return null if the input is valid
//                   },
//                 ),
//                 const SizedBox(height: 20.0),
//                 const SizedBox(height: 20.0),
//                 ,
//                 const SizedBox(height: 20.0),
//                 ElevatedButton(
//                   onPressed: () {
//                     if (_formKey.currentState!.validate()) {
//                       Get.to(BirdDetailScreen());
//                     }
//                   },
//                   child: const Text('Next'),
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
