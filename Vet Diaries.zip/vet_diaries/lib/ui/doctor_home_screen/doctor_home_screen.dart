import 'package:firebase_auth/firebase_auth.dart';
import 'package:vet_diaries/ui/medicine/medicine_record/medicine_record.dart';
import 'package:vet_diaries/ui/medicine/search_patient/search_patient.dart';
import 'package:vet_diaries/ui/record_type_animals_patient/record_type_animals_patient.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class DoctorHomePage extends StatelessWidget {
  const DoctorHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          'Doctor Panel',
          style: btnTextStyle.copyWith(color: Colors.white, fontSize: 35),
        ),
      ),
      body: Container(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Text(
              //   "Doctor Patient record",
              //   style: btnTextStyle.copyWith(color: Colors.blue, fontSize: 35),
              // ),
              ElevatedButton(
                onPressed: () {
                  Get.to(const RecordTypePatient());
                  // Navigator.pushNamed(context, '/select type1');
                },
                child: Text(
                  'Create a New Patient',
                  style: btnTextStyle,
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Get.to(EditRecordScreen());
                },
                child: Text(
                  'Edit Previous Patient',
                  style: btnTextStyle,
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Get.to(ViewSearchMedicinePatient());
                },
                child: Text(
                  'View Medicine Record',
                  style: btnTextStyle,
                ),
              ),
              ElevatedButton(
                onPressed: () async {
                  await logout();

                  Navigator.pushReplacementNamed(context, '/');
                },
                child: Text(
                  'Logout',
                  style: btnTextStyle,
                ),
              ),
            ],
          )),
    );
  }

  Future<void> logout() async {
    // Log out from Firebase
    await FirebaseAuth.instance.signOut();

    // Clear SharedPreferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
