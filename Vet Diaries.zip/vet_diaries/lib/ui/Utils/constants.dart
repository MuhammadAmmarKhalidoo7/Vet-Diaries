import 'package:vet_diaries/ui/view_barrel.dart';

class EmailValidator {
  static final RegExp _emailRegExp = RegExp(
    r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$',
  );

  static bool isValid(String email) {
    return _emailRegExp.hasMatch(email);
  }
}

var btnTextStyle = const TextStyle(
  color: Colors.white,
  fontSize: 24,
  fontWeight: FontWeight.bold,
  letterSpacing: 1,
  wordSpacing: 2,
);

String doctorsCollection = "doctors";
// some constants
String animal = 'animal';
String bird = 'bird';
bool isLogin = true;
bool isRemeberMe = true;
bool isAdmin = true;
