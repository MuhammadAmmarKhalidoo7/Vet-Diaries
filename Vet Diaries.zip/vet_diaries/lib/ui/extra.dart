
// class OwnerInfoAnimalDoctor extends StatelessWidget {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//   final TextEditingController _nameController = TextEditingController();
//   final TextEditingController _cnicController = TextEditingController();
//   final TextEditingController _addressController = TextEditingController();
//   final TextEditingController _emailController = TextEditingController();

//   OwnerInfoAnimalDoctor({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Animals'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//               const Text(
//                 "Enter owner info:",
//                 style: TextStyle(
//                   color: Colors.black,
//                   fontSize: 20,
//                   fontWeight: FontWeight.bold,
//                   letterSpacing: 1,
//                   wordSpacing: 2,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               TextFormField(
//                 controller: _nameController,
//                 decoration: const InputDecoration(
//                   labelText: 'Name',
//                   hintText: 'Enter name here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Name is required';
//                   }
//                   return null; // Return null if the input is valid
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _cnicController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'CNIC',
//                   hintText: 'Enter CNIC here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'CNIC is required';
//                   }
//                   // You can add more CNIC validation logic here if needed
//                   return null; // Return null if the input is valid
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _addressController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Address',
//                   hintText: 'Enter address here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Address is required';
//                   }
//                   // You can add more address validation logic here if needed
//                   return null; // Return null if the input is valid
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _emailController,
//                 obscureText: false,
//                 decoration: const InputDecoration(
//                   labelText: 'Email',
//                   hintText: 'Enter Email here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Email is required';
//                   }
//                   // Email validation using regular expression
//                   const emailPattern =
//                       r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$';
//                   final RegExp regex = RegExp(emailPattern);
//                   if (!regex.hasMatch(value)) {
//                     return 'Enter a valid email address';
//                   }
//                   return null; // Return null if the input is valid
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               ElevatedButton(
//                 onPressed: () {
//                   if (_formKey.currentState!.validate()) {
//                     Navigator.pushNamed(context, '/animal details1');
//                   }
//                 },
//                 child: const Text('Next'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// class AnimalDetailDoctor extends StatelessWidget {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//   final TextEditingController _animalTypeController = TextEditingController();
//   final TextEditingController _ageController = TextEditingController();
//   final TextEditingController _diagnosedDiseaseController =
//       TextEditingController();
//   final TextEditingController _nextVisitController = TextEditingController();
//   final TextEditingController _medicineGivenController =
//       TextEditingController();
//   final TextEditingController _medicineChargesController =
//       TextEditingController();

//   AnimalDetailDoctor({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Animals'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//               const Text(
//                 "Enter Animal Details:",
//                 style: TextStyle(
//                   color: Colors.black,
//                   fontSize: 20,
//                   fontWeight: FontWeight.bold,
//                   letterSpacing: 1,
//                   wordSpacing: 2,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               TextFormField(
//                 controller: _animalTypeController,
//                 decoration: const InputDecoration(
//                   labelText: 'Animal type',
//                   hintText: 'Enter animal type here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Animal type is required';
//                   }
//                   return null; // Return null if the input is valid
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _ageController,
//                 // obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Age',
//                   hintText: 'Enter animal age here',
//                 ),
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _diagnosedDiseaseController,
//                 // obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Enter diagnosed disease',
//                   hintText: 'Enter diagnosed disease here',
//                 ),
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _nextVisitController,
//                 // obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Next visit',
//                   hintText: '',
//                 ),
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _medicineGivenController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Medicine given',
//                   hintText: 'Enter given medicine here',
//                 ),
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 controller: _medicineChargesController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Medicine charges',
//                   hintText: 'RS:',
//                 ),
//               ),
//               const SizedBox(height: 20.0),
//               ElevatedButton(
//                 onPressed: () {
//                   if (_formKey.currentState!.validate()) {
//                     Navigator.pushNamed(context, '/saved');
//                   }
//                 },
//                 child: const Text('Save'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }




// class OwnerInfoBirdDoctor extends StatefulWidget {
//   const OwnerInfoBirdDoctor({super.key});

//   @override
//   // ignore: library_private_types_in_public_api
//   _OwnerInfoBirdDoctorState createState() => _OwnerInfoBirdDoctorState();
// }

// class _OwnerInfoBirdDoctorState extends State<OwnerInfoBirdDoctor> {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Birds'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//               const Text(
//                 "Enter owner info:",
//                 style: TextStyle(
//                   color: Colors.black,
//                   fontSize: 20,
//                   fontWeight: FontWeight.bold,
//                   letterSpacing: 1,
//                   wordSpacing: 2,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               TextFormField(
//                 decoration: const InputDecoration(
//                   labelText: 'Name',
//                   hintText: 'Enter name here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Name is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {},
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'CNIC',
//                   hintText: 'Enter CNIC here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'CNIC is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {},
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Address',
//                   hintText: 'Enter address here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Address is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {},
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Email',
//                   hintText: 'Enter Email here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Email is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {},
//               ),
//               const SizedBox(height: 20.0),
//               ElevatedButton(
//                 onPressed: () {
//                   if (_formKey.currentState!.validate()) {
//                     _formKey.currentState!.save();
//                     // You can use the values of _name, _cnic, _address, and _email here
//                     Navigator.pushNamed(context, '/bird details1');
//                   }
//                 },
//                 child: const Text('Next'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// class BirdDetailScreenDoctor extends StatefulWidget {
//   const BirdDetailScreenDoctor({super.key});

//   @override
//   // ignore: library_private_types_in_public_api
//   _BirdDetailScreenDoctorState createState() => _BirdDetailScreenDoctorState();
// }

// class _BirdDetailScreenDoctorState extends State<BirdDetailScreenDoctor> {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//   // ignore: unused_field
//   String _birdType = '';
//   // ignore: unused_field
//   String _age = '';
//   // ignore: unused_field
//   String _diagnosedDisease = '';
//   // ignore: unused_field
//   String _nextVisit = '';
//   // ignore: unused_field
//   String _medicineGiven = '';
//   // ignore: unused_field
//   String _medicineCharges = '';

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Birds'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//               const Text(
//                 "Enter Bird Details:",
//                 style: TextStyle(
//                   color: Colors.black,
//                   fontSize: 20,
//                   fontWeight: FontWeight.bold,
//                   letterSpacing: 1,
//                   wordSpacing: 2,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               TextFormField(
//                 decoration: const InputDecoration(
//                   labelText: 'Bird type',
//                   hintText: 'Enter bird type here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Bird type is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {
//                   _birdType = value!;
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Age',
//                   hintText: 'Enter bird age here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Age is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {
//                   _age = value!;
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Enter diagnosed disease',
//                   hintText: 'Enter diagnosed disease here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Diagnosed disease is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {
//                   _diagnosedDisease = value!;
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Next visit',
//                   hintText: '',
//                 ),
//                 onSaved: (value) {
//                   _nextVisit = value!;
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Medicine given',
//                   hintText: 'Enter given medicine here',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Medicine given is required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {
//                   _medicineGiven = value!;
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               TextFormField(
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: 'Medicine charges',
//                   hintText: 'RS:',
//                 ),
//                 validator: (value) {
//                   if (value!.isEmpty) {
//                     return 'Medicine charges are required';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) {
//                   _medicineCharges = value!;
//                 },
//               ),
//               const SizedBox(height: 20.0),
//               ElevatedButton(
//                 onPressed: () {
//                   if (_formKey.currentState!.validate()) {
//                     _formKey.currentState!.save();
//                     // You can use the values of _birdType, _age, _diagnosedDisease, _nextVisit, _medicineGiven, and _medicineCharges here
//                     Navigator.pushNamed(context, '/saved');
//                   }
//                 },
//                 child: const Text('Save'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }