class OwnerInfoData {
  final String name;
  final String cnic;
  final String address;
  final String email;

  OwnerInfoData({
    required this.name,
    required this.cnic,
    required this.address,
    required this.email,
  });
}
