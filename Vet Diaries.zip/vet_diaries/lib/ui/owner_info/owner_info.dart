import 'package:vet_diaries/ui/owner_info/model/owner_info_model.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class OwnerInfo extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _cnicController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final _cnicRegex = RegExp(r'^\d{13}$');
  final String type;

  OwnerInfo(
      {super.key, required this.type}); // Regular expression for 13 digits

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(type == animal ? 'Animals' : "Birds"),
      ),
      body: Container(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  "Enter owner info:",
                  style:
                      btnTextStyle.copyWith(color: Colors.blue, fontSize: 35),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name',
                    hintText: 'Enter name here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Name is required';
                    }
                    return null; // Return null if the input is valid
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  keyboardType: TextInputType.number,
                  controller: _cnicController,
                  decoration: const InputDecoration(
                    // border: OutlineInputBorder(),
                    labelText: 'Enter CNIC',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter CNIC';
                    } else if (!_cnicRegex.hasMatch(value)) {
                      return 'Invalid CNIC format. Please enter a valid CNIC';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _addressController,
                  decoration: const InputDecoration(
                    labelText: 'Address',
                    hintText: 'Enter address here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Address is required';
                    }
                    // You can add more address validation logic here if needed
                    return null; // Return null if the input is valid
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'Enter Email here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Email is required';
                    }
                    // Email validation using regular expression
                    const emailPattern =
                        r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$';
                    final RegExp regex = RegExp(emailPattern);
                    if (!regex.hasMatch(value)) {
                      return 'Enter a valid email address';
                    }
                    return null; // Return null if the input is valid
                  },
                ),
                const SizedBox(height: 20.0),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      Get.to(PatientDetailScreen(
                        type: type,
                        ownerInfo: OwnerInfoData(
                          name: _nameController.text,
                          cnic: _cnicController.text,
                          address: _addressController.text,
                          email: _emailController.text,
                        ),
                      ));

                      // Navigator.pushNamed(context, '/animal details');
                    }
                  },
                  child: const Text('Next'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
