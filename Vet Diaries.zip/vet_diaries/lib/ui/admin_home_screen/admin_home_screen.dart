import 'package:firebase_auth/firebase_auth.dart';
import 'package:vet_diaries/ui/announcemetPage/announcement_list_page.dart';
import 'package:vet_diaries/ui/helpline_announcement/announcement_upload_page.dart';
import 'package:vet_diaries/ui/medicine/medicine_record/medicine_record.dart';
import 'package:vet_diaries/ui/medicine/search_patient/search_patient.dart';
import 'package:vet_diaries/ui/record_type_animals_patient/record_type_animals_patient.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class AdminHomePage extends StatefulWidget {
  const AdminHomePage({super.key});

  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  bool isAdmin =
      false; // Default value, you may want to fetch it from SharedPreferences
  @override
  void initState() {
    super.initState();
    _loadIsAdminValue();
  }

  Future<void> _loadIsAdminValue() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      isAdmin = prefs.getBool('isAdmin') ?? false;
      print(isAdmin);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'Admin Panel',
          style: btnTextStyle.copyWith(color: Colors.white, fontSize: 35),
        ),
        // actions: [
        //   if (isAdmin)
        //     IconButton(
        //       icon: const Icon(
        //         Icons.upload,
        //         color: Colors.white,
        //       ),
        //       onPressed: () {
        //         // Navigate to the uploads/announcements page
        //         // You need to define the route or use Navigator.push
        //         Get.to(const AnnouncementUploadPage());
        //       },
        //     ),
        // ],
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,

          children: [
            // Text(
            //   'Admin Patient record',
            //   textAlign: TextAlign.center,
            //   style: btnTextStyle.copyWith(color: Colors.blue, fontSize: 35),
            // ),
            const SizedBox(height: 100),
            ElevatedButton(
              onPressed: () {
                Get.to(const RecordTypePatient());
                // Navigator.pushNamed(context, '/select type');
                const Padding(padding: EdgeInsets.all(8.0));
              },
              child: Text(
                'Create New Patient',
                style: btnTextStyle,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Get.to(EditRecordScreen());
                // Navigator.pushNamed(context, '/edit');
                const Padding(padding: EdgeInsets.all(8.0));
              },
              child: Text(
                'Edit previous patient ',
                style: btnTextStyle,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Get.to(ViewSearchMedicinePatient());
                const Padding(padding: EdgeInsets.all(8.0));
              },
              child: Text(
                'view medicine record',
                style: btnTextStyle,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Get.to(const AnnouncementUploadPage());

                const Padding(padding: EdgeInsets.all(8.0));
              },
              child: Text(
                'Create Announcement',
                style: btnTextStyle,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Get.to(const AnnouncementsListPage());
                const Padding(padding: EdgeInsets.all(8.0));
              },
              child: Text(
                'Edit Announcement',
                style: btnTextStyle,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () async {
                await logout();

                Navigator.pushReplacementNamed(context, '/');
              },
              child: Text(
                'Logout',
                style: btnTextStyle,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> logout() async {
    // Log out from Firebase
    await FirebaseAuth.instance.signOut();

    // Clear SharedPreferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
