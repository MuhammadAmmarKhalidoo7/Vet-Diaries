import 'package:vet_diaries/ui/edit/records_list/records_list.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class EditRecordTypePatient extends StatelessWidget {
  const EditRecordTypePatient({
    super.key,
    required this.cnic,
    required this.animalData,
    required this.birdData,
  });

  final String cnic;
  final List<Map<String, dynamic>> animalData;
  final List<Map<String, dynamic>> birdData;

  @override
  Widget build(BuildContext context) {
    print(animalData);
    print(birdData);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select type'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Card(
            child: Image.asset(
              'images/animal.jpg',
              height: 150.0,
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              Get.to(RecordsLists(
                type: animal,
                patientData: animalData,
              ));
            },
            child: const Text('Edit Animal Record'),
          ),
          const SizedBox(height: 30),
          Card(
            child: Image.asset(
              'images/bird.jpg',
              height: 190.0,
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              Get.to(RecordsLists(
                type: bird,
                patientData: birdData,
              ));
            },
            child: const Text('Edit Bird Record'),
          ),
          const Row()
        ],
      ),
    );
  }
}
