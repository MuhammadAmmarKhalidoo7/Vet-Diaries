import 'package:intl/intl.dart';
import 'package:vet_diaries/services/firebase_service.dart';
import 'package:vet_diaries/ui/owner_info/model/owner_info_model.dart';
import 'package:vet_diaries/ui/record_save_screen/record_save_screen.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class EditPatientDetailScreen extends StatefulWidget {
  const EditPatientDetailScreen(
      {super.key,
      required this.type,
      required this.ownerInfo,
      required this.patientData});
  final String type;

  final Map<String, dynamic> patientData;

  final OwnerInfoData ownerInfo;
  @override
  State<EditPatientDetailScreen> createState() =>
      _EditPatientDetailScreenState();
}

class _EditPatientDetailScreenState extends State<EditPatientDetailScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  late TextEditingController _ageController;

  late TextEditingController _diagnosedDiseaseController;

  late TextEditingController _nextVisitController;

  late TextEditingController _medicineGivenController;

  late TextEditingController _medicineChargesController;
  String selectedAnimalType = 'Dog';
  String selectedBirdType = 'Parrot';

  DateTime? selectedDate;

  @override
  void initState() {
    super.initState();
    _ageController =
        TextEditingController(text: widget.patientData['age'].toString());
// _cnicController=  TextEditingController(text: widget.patientData['cnic'].toString());
    _diagnosedDiseaseController = TextEditingController(
        text: widget.patientData['diagnosedDisease'].toString());
    _nextVisitController =
        TextEditingController(text: widget.patientData['nextVisit'].toString());
    _medicineGivenController = TextEditingController(
        text: widget.patientData['medicineGiven'].toString());
    _medicineChargesController = TextEditingController(
        text: widget.patientData['medicineCharges'].toString());
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2050),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        _nextVisitController.text = DateFormat('dd/MM/yyyy').format(picked);
      });
    }
  }

  final List<String> animalTypes = ['Dog', 'Cat', 'Bird', 'Fish', 'other'];
  List<String> birdTypes = [
    'Parrot',
    'Canary',
    'Sparrow',
    'Finch',
    'Cockatoo',
    'other'
  ];
  bool isOtherType = false;

  final TextEditingController otherTypeController = TextEditingController();

  final FirebaseServices _firebaseServices = FirebaseServices();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.type == animal ? 'Animals' : "Birds"),
      ),
      body: Container(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  widget.type == animal
                      ? "Enter Animal Details:"
                      : "Enter Bird Details:",
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    wordSpacing: 2,
                  ),
                ),
                const SizedBox(height: 20),
                // DropdownButtonFormField<String>(
                //   value: widget.type == animal
                //       ? selectedAnimalType
                //       : selectedBirdType,
                //   items: widget.type == animal
                //       ? animalTypes.map((String type) {
                //           return DropdownMenuItem<String>(
                //             value: type,
                //             child: Text(type),
                //           );
                //         }).toList()
                //       : birdTypes.map((String type) {
                //           return DropdownMenuItem<String>(
                //             value: type,
                //             child: Text(type),
                //           );
                //         }).toList(),
                //   onChanged: (String? newValue) {
                //     setState(() {
                //       widget.type == animal
                //           ? selectedAnimalType = newValue!
                //           : selectedBirdType = newValue!;
                //     });
                //   },
                //   decoration: InputDecoration(
                //     labelText:
                //         widget.type == animal ? 'Animal Type' : 'Bird Type',
                //     hintText: widget.type == animal
                //         ? 'Select an animal type'
                //         : 'Select an bird type',
                //   ),
                //   validator: (value) {
                //     if (value == null || value.isEmpty) {
                //       return 'Please select a type';
                //     }
                //     return null;
                //   },
                // ),
                if (!isOtherType)
                  DropdownButtonFormField<String>(
                    value: isOtherType
                        ? 'Other'
                        : (widget.type == 'animal'
                            ? selectedAnimalType
                            : selectedBirdType),

                    items: widget.type == animal
                        ? animalTypes.map((String type) {
                            return DropdownMenuItem<String>(
                              value: type,
                              child: Text(type),
                            );
                          }).toList()
                        : birdTypes.map((String type) {
                            return DropdownMenuItem<String>(
                              value: type,
                              child: Text(type),
                            );
                          }).toList(),
                    // items: [
                    //   ...animalTypes.map((String type) {
                    //     return DropdownMenuItem<String>(
                    //       value: type,
                    //       child: Text(type),
                    //     );
                    //   }),
                    //   const DropdownMenuItem<String>(
                    //     value: 'other',
                    //     child: Text('other'),
                    //   ),
                    // ],
                    onChanged: (String? newValue) {
                      setState(() {
                        if (newValue == 'other') {
                          isOtherType = true;
                        } else {
                          isOtherType = false;
                          // selectedAnimalType = newValue!;
                          widget.type == animal
                              ? selectedAnimalType = newValue!
                              : selectedBirdType = newValue!;
                        }
                      });
                    },
                    decoration: InputDecoration(
                      labelText:
                          widget.type == animal ? 'Animal Type' : 'Bird Type',
                      hintText: widget.type == animal
                          ? 'Select an animal type'
                          : 'Select an bird type',
                    ),
                    validator: (value) {
                      if (isOtherType && value == null || value!.isEmpty) {
                        return 'Please enter a type';
                      }
                      return null;
                    },
                  ),
                if (isOtherType)
                  TextFormField(
                    controller: otherTypeController,
                    decoration: InputDecoration(
                      labelText: widget.type == animal
                          ? 'Custom Animal Type'
                          : 'Custom Bird Type',
                      hintText: widget.type == animal
                          ? 'Enter a custom animal type'
                          : 'Enter a custom bird type',
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a type';
                      }
                      return null;
                    },
                  ),

                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _ageController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Age',
                    hintText: widget.type == animal
                        ? 'Enter animal age here'
                        : 'Enter bird age here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Age is required';
                    }
                    return null; // Return null if the input is valid
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _diagnosedDiseaseController,
                  obscureText: false,
                  decoration: const InputDecoration(
                    labelText: 'Enter diagnosed disease',
                    hintText: 'Enter diagnosed disease here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Diagnosed disease is required';
                    }
                    return null; // Return null if the input is valid
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  onTap: () {
                    _selectDate(context);
                  },
                  controller: _nextVisitController,
                  decoration: const InputDecoration(
                    labelText: 'Next visit',
                    hintText: '',
                  ),
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _medicineGivenController,
                  obscureText: false,
                  decoration: const InputDecoration(
                    labelText: 'Medicine given',
                    hintText: 'Enter given medicine here',
                  ),
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _medicineChargesController,
                  obscureText: false,
                  decoration: const InputDecoration(
                    labelText: 'Medicine charges',
                    hintText: 'RS:',
                  ),
                ),
                const SizedBox(height: 20.0),
                ElevatedButton(
                  onPressed: () async {
                    DateTime now = DateTime.now();
                    String formattedDate = DateFormat('dd/MM/yyyy').format(now);
                    if (_formKey.currentState!.validate()) {
                      Map<String, dynamic> patientDate = {
                        // 'doctorName':widget.userName,
                        'name': widget.ownerInfo.name,
                        'cnic': widget.ownerInfo.cnic,
                        'address': widget.ownerInfo.address,
                        'email': widget.ownerInfo.email,
                        'type': widget.type,
                        'animalType': widget.type == animal
                            ? isOtherType == true
                                ? otherTypeController.text
                                : selectedAnimalType
                            : null,
                        'birdType': widget.type == bird
                            ? isOtherType == true
                                ? otherTypeController.text
                                : selectedBirdType
                            : null,
                        // 'animalType':
                        //     widget.type == animal ? selectedAnimalType : null,
                        // 'birdType':
                        //     widget.type == bird ? selectedBirdType : null,
                        'age': _ageController.text,
                        "visitedDate": formattedDate,
                        'diagnosedDisease': _diagnosedDiseaseController.text,
                        'nextVisit': _nextVisitController.text,
                        'medicineGiven': _medicineGivenController.text,
                        'medicineCharges': _medicineChargesController.text,
                        "doctorName": "Dr. Ammar"
                      };
                      await _firebaseServices.updatePatientData(patientDate);

                      Get.to(const RecordSavedDoneDoctor());
                      // Navigator.pushNamed(context, '/done');
                    }
                  },
                  child: const Text('Save'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
