import 'package:vet_diaries/ui/edit/edit_patient_detail_screen/edit_patient_detail_screen.dart';
import 'package:vet_diaries/ui/owner_info/model/owner_info_model.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class EditOwnerInfo extends StatefulWidget {
  final Map<String, dynamic> patientData;

  final String type;
  const EditOwnerInfo(
      {super.key, required this.type, required this.patientData});
  @override
  State<EditOwnerInfo> createState() => _EditOwnerInfoState();
}

class _EditOwnerInfoState extends State<EditOwnerInfo> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  late TextEditingController _nameController;

  // late TextEditingController _cnicController ;

  late TextEditingController _addressController;

  late TextEditingController _emailController;

  final _cnicRegex = RegExp(r'^\d{13}$');

  // Regular expression for 13 digits
  @override
  void initState() {
    super.initState();
    _nameController =
        TextEditingController(text: widget.patientData['name'].toString());
// _cnicController=  TextEditingController(text: widget.patientData['cnic'].toString());
    _addressController =
        TextEditingController(text: widget.patientData['address'].toString());
    _emailController =
        TextEditingController(text: widget.patientData['email'].toString());
  }

  @override
  Widget build(BuildContext context) {
    print(widget.patientData);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.type == animal ? 'Animals' : "Birds"),
      ),
      body: Container(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  "Enter owner info:",
                  style:
                      btnTextStyle.copyWith(color: Colors.blue, fontSize: 35),
                ),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  "CNIC",
                  style:
                      btnTextStyle.copyWith(color: Colors.blue, fontSize: 25),
                ),
                Text(
                  widget.patientData['cnic'].toString(),
                  style:
                      btnTextStyle.copyWith(color: Colors.black, fontSize: 16),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name',
                    hintText: 'Enter name here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Name is required';
                    }
                    return null; // Return null if the input is valid
                  },
                  // Add this line to pre-fill the text field
                ),
                const SizedBox(height: 20.0),
                // TextFormField(
                //   controller: _cnicController,
                //   decoration: const InputDecoration(
                //     // border: OutlineInputBorder(),
                //     labelText: 'Enter CNIC',
                //   ),
                //   validator: (value) {
                //     if (value!.isEmpty) {
                //       return 'Please enter CNIC';
                //     } else if (!_cnicRegex.hasMatch(value)) {
                //       return 'Invalid CNIC format. Please enter a valid CNIC';
                //     }
                //     return null;
                //   },
                // ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _addressController,
                  decoration: const InputDecoration(
                    labelText: 'Address',
                    hintText: 'Enter address here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Address is required';
                    }
                    // You can add more address validation logic here if needed
                    return null; // Return null if the input is valid
                  },
                  // Add this line to pre-fill the text field
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'Enter Email here',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Email is required';
                    }
                    // Email validation using regular expression
                    const emailPattern =
                        r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$';
                    final RegExp regex = RegExp(emailPattern);
                    if (!regex.hasMatch(value)) {
                      return 'Enter a valid email address';
                    }
                    return null; // Return null if the input is valid
                  },
                  // Add this line to pre-fill the text field
                ),
                const SizedBox(height: 20.0),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      Get.to(EditPatientDetailScreen(
                        patientData: widget.patientData,
                        type: widget.type,
                        ownerInfo: OwnerInfoData(
                          name: _nameController.text,
                          cnic: widget.patientData['cnic'].toString(),
                          address: _addressController.text,
                          email: _emailController.text,
                        ),
                      ));

                      // Navigator.pushNamed(context, '/animal details');
                    }
                  },
                  child: const Text('Next'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
