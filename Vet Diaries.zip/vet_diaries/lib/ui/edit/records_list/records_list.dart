import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:vet_diaries/ui/edit/edit_owner_info/edit_owner_info.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class RecordsLists extends StatefulWidget {
  const RecordsLists({
    super.key,
    required this.type,
    required this.patientData,
  });
  final String type;
  final List<Map<String, dynamic>> patientData;

  @override
  State<RecordsLists> createState() => _RecordsListsState();
}

class _RecordsListsState extends State<RecordsLists> {
  late Future<bool> isAdmin;
  Future<bool> checkUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? isAdmin = prefs.getBool('isAdmin');
    return isAdmin ?? false;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isAdmin = checkUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title:
              Text(widget.type == animal ? "Animals Record" : "Birds Record")),
      body: Column(
        children: [
          Container(
            decoration: BoxDecoration(color: Colors.blue, border: Border.all()),
            height: 100,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  widget.type == animal
                      ? "List of Animals Record"
                      : "List of Birds Record",
                  style: btnTextStyle,
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListView.builder(
                itemCount: widget.patientData.length,
                itemBuilder: (context, index) {
                  var animalType = widget.type == animal
                      ? widget.patientData[index]['animalType'] ?? 'Animal Type'
                      : widget.patientData[index]['birdType'] ?? 'Bird Type';

                  print("abc${widget.patientData[index]}");
                  return Card(
                    child: ListTile(
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () async {
                          if (await isAdmin) {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  title: const Text('Confirm Delete'),
                                  content: const Text(
                                      'Are you sure you want to delete this record?'),
                                  actions: <Widget>[
                                    TextButton(
                                      child: const Text('Cancel'),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    ),
                                    TextButton(
                                      child: const Text('OK'),
                                      onPressed: () {
                                        try {
                                          print(
                                              "${widget.patientData[index]['id']} sfasjfa");
                                          print("Delete");
                                          // Replace 'collectionName' with the name of your collection
                                          FirebaseFirestore.instance
                                              .collection("patients")
                                              .doc(widget.patientData[index]
                                                  ['id'])
                                              .delete();
                                          setState(() {
                                            widget.patientData.removeAt(index);
                                          });
                                          Navigator.of(context).pop();
                                        } catch (e) {
                                          print("Error deleting record: $e");
                                        }
                                      },
                                    ),
                                  ],
                                );
                              },
                            );
                          } else {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  title: const Text('Permission Denied'),
                                  content: const Text(
                                      'You do not have permission to delete this record.'),
                                  actions: <Widget>[
                                    TextButton(
                                      child: const Text('OK'),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    ),
                                  ],
                                );
                              },
                            );
                          }
                        },
                      ),
                      onTap: () {
                        Get.to(
                          EditOwnerInfo(
                            type: widget.type,
                            patientData: widget.patientData[index],
                          ),
                        );
                      },
                      title: Text(animalType.toString()),
                    ),
                  );
                }),
          ))
        ],
      ),
    );
  }
}
