import 'package:vet_diaries/ui/authentication/signup_success_doctor/signup_success_doctor.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class MedicineRecord extends StatefulWidget {
  const MedicineRecord({super.key, required this.data});
  final List<Map<String, dynamic>> data;
  @override
  // ignore: library_private_types_in_public_api
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<MedicineRecord> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(widget.data.length);
  }

  @override
  Widget build(BuildContext context) {
    print("${widget.data} dataMedi");
    return Scaffold(
      appBar: AppBar(
        title: const Text('Medicine Record'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (int i = 0; i < widget.data.length; i++) ...[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 6),
                          Text(
                            "Medicine Name",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Medicine Name from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['medicineGiven']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Doctor Name",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Doctor Name from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['doctorName']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Patient Owner Name",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Medicine Name from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['name']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            widget.data.isNotEmpty
                                ? widget.data[i]['type'] == "animal"
                                    ? "Animal Type"
                                    : "Bird Type"
                                : "Type",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Patient Type from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['type'] == "animal"
                                    ? widget.data[i]['animalType']
                                    : widget.data[i]['birdType']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Patient Age",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Medicine Name from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['age']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Medicine Charges",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Medicine Name from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['medicineCharges']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Visited Date",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Date from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['visitedDate']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Next Visit Date",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Date from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['nextVisit']
                                : 'No data available',
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Patient Type",
                            style: btnTextStyle.copyWith(color: Colors.blue),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            // Display Patient Type from the data
                            widget.data.isNotEmpty
                                ? widget.data[i]['type']
                                : 'No data available',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
              RoundedButton(
                buttonColor: Colors.blue,
                textColor: Colors.white,
                buttonText: 'Finish',
                onPressed: () {
                  Get.back();
                  Get.back();
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
