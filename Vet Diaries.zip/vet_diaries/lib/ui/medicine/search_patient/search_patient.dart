import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:vet_diaries/ui/authentication_screen/authentication_screen.dart';
import 'package:vet_diaries/ui/edit/edit_record_page/edit_record_page.dart';
import 'package:vet_diaries/ui/medicine/medicine_record/medicine_record.dart';
import 'package:vet_diaries/ui/record_type_animals_patient/record_type_animals_patient.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class ViewSearchMedicinePatient extends StatelessWidget {
  final _cnicRegex = RegExp(r'^\d{13}$'); // Regular expression for 13 digits
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _cnicController = TextEditingController();
  ViewSearchMedicinePatient({super.key}); // GlobalKey for the form

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit'),
      ),
      body: Container(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Image.asset(
                'images/admin.jpg', // Replace with your logo image path
                height: 150.0,
              ),
              TextFormField(
                controller: _cnicController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Enter CNIC',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter CNIC';
                  } else if (!_cnicRegex.hasMatch(value)) {
                    return 'Invalid CNIC format. Please enter a valid CNIC';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  // Check if the form is valid before proceeding
                  if (_formKey.currentState!.validate()) {
                    // Form is valid, you can navigate to the next screen or perform other actions
                    // For example, you can use Navigator to push the next screen
                    searchPatient(
                        context, _cnicController.text.trim().toString());
                  }
                },
                child: const Text('Search'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void searchPatient(BuildContext context, String cnic) async {
    // Check if the CNIC exists in the patient collection
    bool patientExists = await checkIfPatientExists(cnic);

    if (patientExists) {
      // CNIC exists, navigate to the MedicineRecord page

      List<Map<String, dynamic>> allPatientData = await fetchPatientData(cnic);
      print("$allPatientData Afdf");
      // List<Map<String, dynamic>> filteredDataAnimal =
      //     allPatientData.where((element) => element['type'] == animal).toList();

      // List<Map<String, dynamic>> filteredDataBird =
      //     allPatientData.where((element) => element['type'] == bird).toList();

      if (allPatientData.isNotEmpty) {
        // Animal data exists, pass it to the MedicineRecord page
        Get.to(MedicineRecord(
          data: allPatientData,
        ));
      }
      // else if (allPatientData.isNotEmpty) {
      //   // Bird data exists, pass it to the MedicineRecord page
      //   Get.to(MedicineRecord(
      //     data: allPatientData,
      //   ));
      // }
      else {
        // No matching data found
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Data Not Found'),
              content: const Text('There is no data for this CNIC.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } else {
      // CNIC does not exist, show a message
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Patient Not Found'),
            content:
                const Text('There is no patient registered with this CNIC.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  ///

  Future<bool> checkIfPatientExists(String cnic) async {
    try {
      // Assuming you have a Firestore collection named 'patients'
      CollectionReference patientsCollection =
          FirebaseFirestore.instance.collection('patients');

      // Query Firestore to check if a patient with the given CNIC exists
      QuerySnapshot querySnapshot =
          await patientsCollection.where('cnic', isEqualTo: cnic).get();

      // If there are documents in the query snapshot, the patient exists
      return querySnapshot.docs.isNotEmpty;
    } catch (e) {
      print('Error checking patient existence: $e');
      return false; // Return false in case of an error
    }
  }

  Future<List<Map<String, dynamic>>> fetchPatientData(String cnic) async {
    try {
      CollectionReference patientCollection =
          FirebaseFirestore.instance.collection("patients");
      QuerySnapshot querySnapshot =
          await patientCollection.where('cnic', isEqualTo: cnic).get();
      List<Map<String, dynamic>> patientDataList = querySnapshot.docs
          .map((DocumentSnapshot document) =>
              document.data() as Map<String, dynamic>)
          .toList();

      return patientDataList;
    } on FirebaseException {
      print("error");
      return [];
    }
  }
}

// void searchPatient(BuildContext context, String cnic) async {
//   // Check if the CNIC exists in the patient collection
//   bool patientExists = await checkIfPatientExists(cnic);

//   if (patientExists) {
//     // CNIC exists, navigate to the RecordTypePatient page

//     List<Map<String, dynamic>> allPatientData = await fetchPatientData(cnic);

//     List<Map<String, dynamic>> filteredDataAnimal =
//         allPatientData.where((element) => element['type'] == animal).toList();

//     List<Map<String, dynamic>> filteredDataBird =
//         allPatientData.where((element) => element['type'] == bird).toList();

//     Get.to(const MedicineRecord());
//   } else {
//     // CNIC does not exist, show a message
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text('Patient Not Found'),
//           content:
//               const Text('There is no patient registered with this CNIC.'),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.pop(context);
//               },
//               child: const Text('OK'),
//             ),
//           ],
//         );
//       },
//     );
//   }
// }
