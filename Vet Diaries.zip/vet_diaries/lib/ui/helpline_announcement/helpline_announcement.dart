// import 'package:flutter/material.dart';

// class HelpLineAndAnnouncements extends StatelessWidget {
//   const HelpLineAndAnnouncements({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Helpline and Announcements'),
//       ),
//       body: const Padding(
//         padding: EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             Text(
//               'Helpline',
//               style: TextStyle(
//                 color: Colors.blue,
//                 fontSize: 24.0,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             Padding(
//               padding: EdgeInsets.symmetric(vertical: 8.0),
//               child: Text(
//                 '727244',
//                 style: TextStyle(
//                   fontSize: 16.0,
//                 ),
//                 textAlign: TextAlign.center,
//               ),
//             ),
//             SizedBox(
//               height: 50,
//             ),
//             Text(
//               'Announcements',
//               style: TextStyle(
//                 color: Colors.blue,
//                 fontSize: 24.0,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             Padding(
//               padding: EdgeInsets.symmetric(vertical: 8.0),
//               child: Text(
//                 'Sponsored by COMSATS University Islamabad, Sahiwal Campus',
//                 style: TextStyle(
//                   fontSize: 16.0,
//                 ),
//                 textAlign: TextAlign.center,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ShowHelpLineAndAnnouncements extends StatelessWidget {
  const ShowHelpLineAndAnnouncements({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Helpline and Announcements'),
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Helpline',
              style: TextStyle(
                color: Colors.blue,
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                '727244',
                style: TextStyle(
                  fontSize: 16.0,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Text(
              'Announcements',
              style: TextStyle(
                color: Colors.blue,
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                'Sponsored by COMSATS University Islamabad, Sahiwal Campus',
                style: TextStyle(
                  fontSize: 16.0,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 8),
            Expanded(
              child: AnnouncementsList(),
            ),
          ],
        ),
      ),
    );
  }
}

// class AnnouncementsList extends StatelessWidget {
//   const AnnouncementsList({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return StreamBuilder(
//       stream:
//           FirebaseFirestore.instance.collection('announcements').snapshots(),
//       builder: (context, snapshot) {
//         if (!snapshot.hasData) {
//           return const DummyAnnouncementCard();
//         }

//         var announcements = snapshot.data!.docs;

//         if (announcements.isEmpty) {
//           return const DummyAnnouncementCard();
//         }

//         return ListView.builder(
//           itemCount: announcements.length,
//           itemBuilder: (context, index) {
//             var announcement = announcements[index];
//             var description = announcement['description'];
//             var imageUrl = announcement['image_url'];

//             return AnnouncementCard(
//               description: description,
//               imageUrl: imageUrl,
//             );
//           },
//         );
//       },
//     );
//   }
// }

class AnnouncementsList extends StatelessWidget {
  const AnnouncementsList({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream:
          FirebaseFirestore.instance.collection('announcements').snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          // Show a loading indicator while waiting for data
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          // Handle errors
          return const Center(child: Text('Error fetching announcements'));
        }

        var announcements = snapshot.data?.docs;

        if (announcements == null || announcements.isEmpty) {
          return const DummyAnnouncementCard();
        }

        return ListView.builder(
          itemCount: announcements.length,
          itemBuilder: (context, index) {
            var announcement = announcements[index];
            var description = announcement['description'];
            var imageUrl = announcement['image_url'];

            return AnnouncementCard(
              description: description,
              imageUrl: imageUrl,
            );
          },
        );
      },
    );
  }
}

class AnnouncementCard extends StatelessWidget {
  final String description;
  final String imageUrl;

  const AnnouncementCard(
      {super.key, required this.description, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Image.network(
              imageUrl,
              height: 150,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                description,
                style: const TextStyle(fontSize: 16.0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DummyAnnouncementCard extends StatelessWidget {
  const DummyAnnouncementCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Image.asset(
              'images/doctorlogin.jpg', // Replace with your dummy image asset
              height: 200,
              fit: BoxFit.fill,
            ),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                'No announcements available',
                style: TextStyle(fontSize: 16.0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
