// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';
// import 'package:cloud_firestore/cloud_firestore.dart';

// class AnnouncementUploadPage extends StatefulWidget {
//   const AnnouncementUploadPage({super.key});

//   @override
//   _AnnouncementUploadPageState createState() => _AnnouncementUploadPageState();
// }

// class _AnnouncementUploadPageState extends State<AnnouncementUploadPage> {
//   File? _image;
//   final TextEditingController _descriptionController = TextEditingController();
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;

//   Future<void> _getImage() async {
//     final imagePicker = ImagePicker();
//     final pickedFile = await imagePicker.pickImage(source: ImageSource.gallery);

//     setState(() {
//       if (pickedFile != null) {
//         _image = File(pickedFile.path);
//       }
//     });
//   }

//   Future<void> _uploadAnnouncement() async {
//     String description = _descriptionController.text.trim();

//     if (_image == null || description.isEmpty) {
//       _showDialog("Description or Image is missing");
//     } else {
//       try {
//         // Upload logic to Firebase Firestore
//         await _firestore.collection('announcements').add({
//           'description': description,
//           'image_url':
//               'placeholder', // You can upload the image to Firebase Storage and use the URL here
//           'timestamp': FieldValue.serverTimestamp(),
//         });

//         print("Announcement uploaded!");
//       } catch (e) {
//         print("Error uploading announcement: $e");
//         _showDialog("Error uploading announcement");
//       }
//     }
//   }

//   void _showDialog(String message) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text("Error"),
//           content: Text(message),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.pop(context);
//               },
//               child: const Text("OK"),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Announcement Page"),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Container(
//               width: 100,
//               height: 100,
//               decoration: BoxDecoration(
//                 color: Colors.grey,
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               child: _image != null
//                   ? Image.file(
//                       _image!,
//                       fit: BoxFit.cover,
//                     )
//                   : IconButton(
//                       icon: const Icon(Icons.photo),
//                       onPressed: _getImage,
//                     ),
//             ),
//             const SizedBox(height: 20),
//             TextField(
//               controller: _descriptionController,
//               decoration: const InputDecoration(
//                 hintText: "Enter Announcement Description",
//               ),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _uploadAnnouncement,
//               child: const Text("Upload Announcement"),
//             ),
//             const SizedBox(height: 20),
//             Expanded(
//               child: StreamBuilder(
//                 stream: _firestore.collection('announcements').snapshots(),
//                 builder: (context, snapshot) {
//                   if (!snapshot.hasData) {
//                     return const CircularProgressIndicator();
//                   }

//                   var announcements = snapshot.data!.docs;

//                   List<Widget> announcementWidgets = [];
//                   for (var announcement in announcements) {
//                     var description = announcement['description'];
//                     var imageUrl = announcement['image_url'];

//                     var announcementWidget = ListTile(
//                       title: Text(description),
//                       leading: Image.network(imageUrl),
//                     );

//                     announcementWidgets.add(announcementWidget);
//                   }

//                   return ListView(
//                     children: announcementWidgets,
//                   );
//                 },
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class AnnouncementUploadPage extends StatefulWidget {
  const AnnouncementUploadPage({Key? key}) : super(key: key);

  @override
  _AnnouncementUploadPageState createState() => _AnnouncementUploadPageState();
}

class _AnnouncementUploadPageState extends State<AnnouncementUploadPage> {
  File? _image;
  final TextEditingController _descriptionController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> _getImage() async {
    final imagePicker = ImagePicker();
    final pickedFile = await imagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      }
    });
  }

  Future<void> _uploadAnnouncement() async {
    String description = _descriptionController.text.trim();

    if (_image == null || description.isEmpty) {
      _showDialog("Description or Image is missing");
    } else {
      try {
        // Upload logic to Firebase Firestore
        setState(() {
          _uploadInProgress = true;
        });
        var imageUrl =
            await _uploadImageToStorage(); // Upload image to storage and get URL
        await _firestore.collection('announcements').add({
          'description': description,
          'image_url': imageUrl,
          'timestamp': FieldValue.serverTimestamp(),
        });

        _showDialog("Announcement uploaded!");
        setState(() {
          _uploadInProgress = false;
        });
        _clearFields(); // Clear fields after successful upload
      } catch (e) {
        setState(() {
          _uploadInProgress = false;
        });
        print("Error uploading announcement: $e");
        _showDialog("Error uploading announcement");
      }
    }
  }

  // Future<String> _uploadImageToStorage() async {
  //   // Placeholder for the actual implementation to upload the image to Firebase Storage
  //   // Replace the following line with your Firebase Storage upload logic
  //   // Example: Upload the image to a 'announcements' folder and return the URL
  //   // For demonstration purposes, returning a placeholder URL
  //   return 'https://example.com/placeholder_image.jpg';
  // }
  Future<String> _uploadImageToStorage() async {
    try {
      setState(() {
        _uploadInProgress = true;
      });
      final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      final firebase_storage.Reference storageReference = firebase_storage
          .FirebaseStorage.instance
          .ref()
          .child('announcements/$fileName.jpg');

      await storageReference.putFile(_image!);

      final String downloadURL = await storageReference.getDownloadURL();
      setState(() {
        _uploadInProgress = false;
      });
      return downloadURL;
    } catch (e) {
      setState(() {
        _uploadInProgress = false;
      });
      print("Error uploading image to storage: $e");
      // You might want to handle the error accordingly
      return ''; // Return an empty string or null to indicate failure
    }
  }

  void _showDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Info"),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  void _clearFields() {
    setState(() {
      _image = null;
      _descriptionController.clear();
    });
  }

  bool _uploadInProgress = false;
  @override
  Widget build(BuildContext context) {
    if (_uploadInProgress) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else {
      return Scaffold(
        appBar: AppBar(
          title: const Text("Announcement Page"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: _image != null
                    ? Image.file(
                        _image!,
                        fit: BoxFit.cover,
                      )
                    : IconButton(
                        icon: const Icon(Icons.photo),
                        onPressed: _getImage,
                      ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  hintText: "Enter Announcement Description",
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _uploadAnnouncement,
                child: const Text("Upload Announcement"),
              ),
              const SizedBox(height: 20),
              // Expanded(
              //   child: StreamBuilder(
              //     stream: _firestore.collection('announcements').snapshots(),
              //     builder: (context, snapshot) {
              //       if (!snapshot.hasData) {
              //         return const CircularProgressIndicator();
              //       }

              //       var announcements = snapshot.data!.docs;

              //       List<Widget> announcementWidgets = [];
              //       for (var announcement in announcements) {
              //         var description = announcement['description'];
              //         var imageUrl = announcement['image_url'];

              //         var announcementWidget = ListTile(
              //           title: Text(description),
              //           leading: Image.network(imageUrl),
              //         );

              //         announcementWidgets.add(announcementWidget);
              //       }

              //       return ListView(
              //         children: announcementWidgets,
              //       );
              //     },
              //   ),
              // ),
            ],
          ),
        ),
      );
    }
  }
}
