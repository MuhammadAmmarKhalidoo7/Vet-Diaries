import 'package:vet_diaries/ui/view_barrel.dart';

class RecordSavedDoneDoctor extends StatelessWidget {
  const RecordSavedDoneDoctor({super.key});

  Future<void> checkAdminStatus(context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isAdmin = prefs.getBool('isAdmin') ?? false;

    if (isAdmin) {
      // User is admin, navigate to admin home page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const AdminHomePage()),
      );
    } else {
      // User is not admin, navigate to doctor home page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const DoctorHomePage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('back'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Row(),
            const SizedBox(height: 50),
            const Text(
              "Patient Record",
              style: TextStyle(
                color: Colors.blue,
                fontSize: 35,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
                wordSpacing: 2,
              ),
            ),
            const SizedBox(height: 100),
            const Text(
              "Saved",
              style: TextStyle(color: Colors.blue, fontSize: 20),
            ),
            const Padding(padding: EdgeInsets.all(8.0)),
            const SizedBox(height: 100),
            ElevatedButton(
              onPressed: () {
                checkAdminStatus(context);
              },
              child: const Text('Done'),
            ),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
