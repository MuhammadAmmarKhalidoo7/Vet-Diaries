import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RoundedButton extends StatelessWidget {
  final String buttonText;
  final Function? onPressed;
  final Color buttonColor;
  final Color textColor;

  const RoundedButton({
    super.key,
    required this.buttonText,
    required this.onPressed,
    this.buttonColor = Colors.white,
    this.textColor = Colors.black,
  });

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: const EdgeInsets.all(8),
      onPressed: () {
        onPressed?.call();
      },
      child: Container(
        height: 50,
        width: 300,
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: const BorderRadius.horizontal(
            left: Radius.circular(25),
            right: Radius.circular(25),
          ),
        ),
        child: Center(
          child: Text(
            buttonText,
            style: TextStyle(
              color: textColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
