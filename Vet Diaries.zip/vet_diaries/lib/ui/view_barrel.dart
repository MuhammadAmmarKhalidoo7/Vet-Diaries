export 'package:flutter/material.dart';
export 'package:shared_preferences/shared_preferences.dart';

export 'package:vet_diaries/ui/Utils/constants.dart';

export 'package:vet_diaries/ui/patient_details_screen/patient_details_screen.dart';
export 'package:vet_diaries/ui/authentication/login_page_doctor/login_page_doctor.dart';
export 'package:vet_diaries/ui/authentication_screen/authentication_screen.dart';
export 'package:vet_diaries/ui/bird_detail_screen/bird_detail_screen.dart';
export 'package:vet_diaries/ui/doctor_home_screen/doctor_home_screen.dart';
export 'package:vet_diaries/ui/edit_record_patient.dart/edit_record_patient.dart';
export 'package:vet_diaries/ui/owner_info/owner_info.dart';
export 'package:vet_diaries/ui/admin_home_screen/admin_home_screen.dart';
export 'package:vet_diaries/ui/create_new_patient_animal/create_new_patient_animal.dart';
export 'package:vet_diaries/ui/widgets/widgets.dart';

export 'package:get/get.dart';
