// import 'package:vet_diaries/ui/view_barrel.dart';

// class CreateNewPatientAnimal extends StatelessWidget {
//   const CreateNewPatientAnimal({super.key});
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // backgroundColor: Colors.blue,
//       appBar: AppBar(
//         title: const Text('Select type'),
//       ),
//       body: Center(
//         child: Column(
//           // mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Padding(
//               padding: EdgeInsets.all(28.0),
//             ),
//             Image.asset(
//               'images/animal.jpg', // Replace with your logo image path
//               height: 150.0,
//             ),
//             const SizedBox(height: 10),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.pushNamed(context, '/animal record');
//               },
//               child: const Text('Amimal'),
//             ),
//             const SizedBox(height: 30),
//             Image.asset(
//               'images/bird.jpg', // Replace with your logo image path
//               height: 190.0,
//             ),
//             const SizedBox(height: 10),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.pushNamed(context, '/bird record');
//               },
//               child: const Text('Bird'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
