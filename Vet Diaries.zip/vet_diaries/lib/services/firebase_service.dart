import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseServices {
  final CollectionReference patientsCollection =
      FirebaseFirestore.instance.collection("patients");

  Future<void> savePatientData(Map<String, dynamic> patientDate, id) async {
    patientsCollection..doc(id).set(patientDate);
  }

  Future<void> updatePatientData(Map<String, dynamic> patientDate) async {
    try {
      // Check if the patient document already exists based on the CNIC
      QuerySnapshot existingPatient = await patientsCollection
          .where('cnic', isEqualTo: patientDate['cnic'])
          .get();

      if (existingPatient.docs.isNotEmpty) {
        // If the patient document exists, update the data
        await patientsCollection
            .doc(existingPatient.docs.first.id)
            .update(patientDate);
      } else {
        // If the patient document doesn't exist, add a new document
        await patientsCollection.add(patientDate);
      }
    } catch (e) {
      print('Error saving patient data: $e');
    }
  }
}
