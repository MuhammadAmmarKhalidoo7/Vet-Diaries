import 'dart:async';

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vet_diaries/ui/view_barrel.dart';

class SplashServices {
  static checkIsLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? isAdmin = prefs.getBool('isAdmin');
    bool? rememberMe = prefs.getBool('rememberMe');

    Timer(const Duration(seconds: 2), () {
      if (rememberMe == true && isAdmin == true) {
        Get.to(const AdminHomePage());
      } else if (rememberMe == true && isAdmin == false) {
        // Navigate to the normal user screen or login screen
        Get.to(const DoctorHomePage());
      } else {
        Get.to(const AuthenticationScreen());
      }
    });

    // if (preferences.getString('type')=='admin')
  }
}
