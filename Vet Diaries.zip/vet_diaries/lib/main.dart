import 'package:firebase_core/firebase_core.dart';
import 'package:vet_diaries/ui/authentication/login_page_admin/login_page_admin.dart';
import 'package:vet_diaries/ui/authentication/signup_page_doctor/signup_page_doctor.dart';
import 'package:vet_diaries/ui/helpline_announcement/helpline_announcement.dart';
import 'package:vet_diaries/ui/splash_screen/splash_screen.dart';
import 'firebase_options.dart';

import 'package:vet_diaries/ui/view_barrel.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  //today date as well in medicine
  runApp(MyApp());
}

// ignore: use_key_in_widget_constructors
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Vet diaries',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: Colors.blue,
        hintColor: Colors.blue,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.blue,
        ),
        inputDecorationTheme: InputDecorationTheme(
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.blue),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.blue.withOpacity(0.5)),
          ),
          labelStyle: const TextStyle(color: Colors.blue),
        ),
        textSelectionTheme: const TextSelectionThemeData(
            cursorColor: Colors.blue, // Set the cursor color
            selectionHandleColor: Colors.blue),
        buttonTheme: const ButtonThemeData(
          buttonColor: Colors.blue,
          textTheme: ButtonTextTheme.primary,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue, // background color
            foregroundColor: Colors.white, // text color
          ),
        ),
      ),
      home: Builder(
        builder: (context) => const SplashScreen(),
      ),
      getPages: [
        GetPage(
          name: '/',
          page: () => const SplashScreen(),
        ),
        GetPage(
          name: '/authentication',
          page: () => const AuthenticationScreen(),
        ),
        GetPage(name: '/adminLogin', page: () => const AdminLoginPage()),
        GetPage(name: '/doctorLogin', page: () => const DoctorLoginPage()),
        GetPage(name: '/doctorSignup', page: () => const DoctorSignUpPage()),
        GetPage(
            name: '/helpLinePage',
            page: () => const ShowHelpLineAndAnnouncements()),

        // Doctor Side
        GetPage(name: '/doctorHomeScreen', page: () => const DoctorHomePage()),
        GetPage(name: '/doctorSignup', page: () => const DoctorSignUpPage()),

        //admin
        GetPage(name: '/adminHomeScreen', page: () => const AdminHomePage()),
      ],
    );
  }
}
