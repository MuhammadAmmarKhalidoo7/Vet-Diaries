package com.example.vet_diaries

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
